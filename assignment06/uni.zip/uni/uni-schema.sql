drop table if exists student;
drop type if exists degree;
drop type if exists subject;
drop table if exists staff;
drop table if exists class;
drop type if exists room;
drop table if exists enrolled;
drop table if exists department;

create type degree as enum (
	'MSc',
	'BSc'
);

create type subject as enum (
	'Animal Science',
	'Law',
	'Psychology',
	'Kinesiology',
	'Architecture',
	'Civil Engineering',
	'Computer Science',
	'Economics',
	'Accounting',
	'History',
	'Mechanical Engineering',
	'Computer Engineering',
	'Finance',
	'Veterinary Medicine',
	'Education',
	'English',
	'Electrical Engineering'
);

create table student (
	studentid int,
	name text,
	major subject,
	pursueddegree degree,
	age int
);

alter table student add primary key (studentid);
alter table student alter column name set not null;
alter table student alter column major set not null;
alter table student alter column pursueddegree set not null;
alter table student alter column age set not null;

create table staff(
	staffid int,
	name text,
	deptid int,
	age int
);

alter table staff add primary key (staffid);
alter table staff alter column name set not null;
alter table staff alter column age set not null;

create type room as enum (
	'Q3',
	'R15',
	'R128',
	'R12',
	'1320 DCL',
	'20 AVW'
);

create table class (
	classid int,
	name text,
	meetsat text,
	room room,
	staffid int
);

alter table class add primary key (classid);
alter table class alter column meetsat set not null;
alter table class alter column name set not null;
alter table class alter column room set not null;
alter table class alter column staffid set not null;

create table enrolled (
	studentid int,
	classid int
);

alter table enrolled add primary key (studentid, classid);

create table department (
	deptid int,
	name text
);

alter table department add primary key (deptid);
alter table department alter column name set not null;
