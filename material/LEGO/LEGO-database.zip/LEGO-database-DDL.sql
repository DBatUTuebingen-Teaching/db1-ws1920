
CREATE SCHEMA IF NOT EXISTS lego;
SET SCHEMA 'lego';

CREATE DOMAIN id AS
  character varying(20);

CREATE DOMAIN rgb AS text
  CHECK (VALUE ~ '^(\d|[a-f]){6}$');

CREATE DOMAIN type AS character(1)
  CHECK (VALUE IN ('B', 'M'));


CREATE TABLE available_in (
  brick id      NOT NULL,
  color integer NOT NULL
);


-- The load process may try to insert duplicates into availble_in: ignore
-- (let the INSERT fail silently)
CREATE RULE available_in_ignore_dupes AS
  ON INSERT TO available_in
  WHERE new = ANY (SELECT available_in FROM available_in)
  DO INSTEAD NOTHING;

--
CREATE TABLE categories (
  cat  integer NOT NULL,
  name text
);


CREATE TABLE colors (
  color     integer NOT NULL,
  name      character varying(30),
  finish    character varying(15),
  rgb       rgb,
  from_year integer,
  to_year   integer
);


CREATE TABLE contains (
  set      id NOT NULL,
  piece    id NOT NULL,
  color    integer NOT NULL,
  extra    boolean NOT NULL,
  quantity integer
);


-- A LEGO piece is either a brick or a minifig (see INHERITS clauses below)
CREATE TABLE pieces (
  piece  id NOT NULL,
  type   type NOT NULL,
  name   text,
  cat    integer,
  weight real,
  img    text
);

-- Table `pieces' represents an abstract concept and may not be instantiated
CREATE RULE pieces_no_inserts AS
  ON INSERT TO pieces
  DO INSTEAD NOTHING;


CREATE TABLE minifigs (
  type type CHECK (type = 'M') DEFAULT 'M'
) INHERITS (pieces);


CREATE TABLE bricks (
  type type CHECK (type = 'B') DEFAULT 'B',
  x    real,
  y    real,
  z    real
) INHERITS (pieces);


-- A table which collects the piece IDs of all bricks and minifigs
-- to serve in foreign key constraints (hack around PostgreSQL deficiency
-- that does not consider child tables in foreign key constraints)
CREATE TABLE all_pieces (
  piece id NOT NULL
);

CREATE RULE minifigs_insert_also_all_pieces AS
  ON INSERT TO minifigs
  DO ALSO INSERT INTO all_pieces VALUES (new.piece);

CREATE RULE minifigs_update_also_all_pieces AS
  ON UPDATE TO minifigs
  DO ALSO UPDATE all_pieces SET piece = new.piece WHERE piece = old.piece;

CREATE RULE minifigs_delete_also_all_pieces AS
  ON DELETE TO minifigs
  DO ALSO DELETE FROM all_pieces WHERE piece = old.piece;

CREATE RULE bricks_insert_also_all_pieces AS
  ON INSERT TO bricks
  DO ALSO INSERT INTO all_pieces VALUES (new.piece);

CREATE RULE bricks_update_also_all_pieces AS
  ON UPDATE TO bricks
  DO ALSO UPDATE all_pieces SET piece = new.piece WHERE piece = old.piece;

CREATE RULE bricks_delete_also_all_pieces AS
  ON DELETE TO bricks
  DO ALSO DELETE FROM all_pieces WHERE piece = old.piece;


CREATE TABLE sets (
  set    id NOT NULL,
  name   text,
  cat    integer,
  x      real,
  y      real,
  z      real,
  weight real,
  year   integer,
  img    text
);


CREATE TABLE replaces (
  piece1 id NOT NULL,
  piece2 id NOT NULL,
  set    id NOT NULL
);


-----------------------------------------------------------------------
-- Constraints

ALTER TABLE categories
  ADD CONSTRAINT categories_pkey PRIMARY KEY (cat);

ALTER TABLE colors
  ADD CONSTRAINT colors_pkey PRIMARY KEY (color);

ALTER TABLE pieces
  ADD CONSTRAINT pieces_pkey PRIMARY KEY (piece),
  ADD CONSTRAINT pieces_cat_fkey FOREIGN KEY (cat) REFERENCES categories(cat);

ALTER TABLE minifigs
  ADD CONSTRAINT minifigs_pkey PRIMARY KEY (piece);

ALTER TABLE bricks
  ADD CONSTRAINT bricks_pkey PRIMARY KEY (piece);

ALTER TABLE all_pieces
  ADD CONSTRAINT all_pieces_pkey PRIMARY KEY (piece);

ALTER TABLE sets
  ADD CONSTRAINT sets_pkey PRIMARY KEY (set),
  ADD CONSTRAINT sets_cat_fkey FOREIGN KEY (cat) REFERENCES categories(cat);

ALTER TABLE available_in
  ADD CONSTRAINT available_in_pkey PRIMARY KEY (brick, color),
  ADD CONSTRAINT available_in_brick_fkey FOREIGN KEY (brick) REFERENCES bricks(piece),
  ADD CONSTRAINT available_in_color_fkey FOREIGN KEY (color) REFERENCES colors(color);

ALTER TABLE replaces
  ADD CONSTRAINT replaces_pkey PRIMARY KEY (piece1, piece2, set),
  ADD CONSTRAINT replaces_piece1_fkey FOREIGN KEY (piece1) REFERENCES all_pieces(piece),
  ADD CONSTRAINT replaces_piece2_fkey FOREIGN KEY (piece2) REFERENCES all_pieces(piece),
  ADD CONSTRAINT replaces_set_fkey FOREIGN KEY (set) REFERENCES sets(set);

ALTER TABLE contains
  ADD CONSTRAINT contains_pkey PRIMARY KEY (set, piece, color, extra),
  ADD CONSTRAINT contains_set_fkey FOREIGN KEY (set) REFERENCES sets(set),
  ADD CONSTRAINT contains_piece_fkey FOREIGN KEY (piece) REFERENCES all_pieces(piece),
  ADD CONSTRAINT contains_color_fkey FOREIGN KEY (color) REFERENCES colors(color);

-----------------------------------------------------------------------
-- Image handling

-- Use PostgreSQL's encode(..., 'base64') built-in function
-- to turn the bitmap's byte array into a base64-encoded string
-- that browsers etc. can display
-- (e.g., see http://base64online.org/decode/)

-- An image cache that maps (bricklink.com) URLs to bitmaps
CREATE TABLE cache (
  url    text NOT NULL,
  bitmap bytea
);

ALTER TABLE cache
  ADD CONSTRAINT cache_pkey PRIMARY KEY (url);
