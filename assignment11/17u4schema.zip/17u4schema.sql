-- Drop already existing tables

DROP TABLE IF EXISTS game CASCADE;
DROP TABLE IF EXISTS cards CASCADE;
DROP TYPE IF EXISTS suit CASCADE; 
DROP TYPE IF EXISTS rank CASCADE;

-- Create needed types
CREATE TYPE suit AS ENUM ('♣' ,'♠',  '♥', '♦');
CREATE TYPE rank AS ENUM ('2', '3', '4', '5', '6',
                          '7', '8', '9', 'B', 'D',
                          'K', '10', 'A');

-- Create tables
CREATE TABLE cards (
    suit suit,
    rank rank,
    value int
);

CREATE TABLE game (
  player text,
  suit   suit,
  rank   rank
);

-- Add Constraints
ALTER TABLE cards ADD PRIMARY KEY (suit, rank);
ALTER TABLE game ADD UNIQUE (suit,rank);
ALTER TABLE game ADD FOREIGN KEY (suit,rank) REFERENCES cards(suit,rank);

-- Insert data into tables
INSERT INTO cards
  (SELECT s.suit::suit, r.rank::rank, r.value
    FROM  (VALUES ('♠'), ('♣'), ('♥'), ('♦')) s(suit),
          (VALUES ('2',2), ('3',3), ('4',4), ('5',5), ('6',6),
                  ('7',7), ('8',8), ('9',9), ('B',10), ('D',10),
                  ('K',10), ('10',10), ('A',11)) r(rank,value)
  );

-- Possible start state of the game
INSERT INTO game VALUES
  ('Madita', '♦', '3'),
  ('Madita', '♦', '5'),
  ('Frida',  '♦', '4'), 
  ('Frida',  '♣', '9'),
  ('Thor',   '♥', 'A'), 
  ('Thor',   '♦', 'B');
